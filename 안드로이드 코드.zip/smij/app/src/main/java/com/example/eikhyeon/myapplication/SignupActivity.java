package com.example.eikhyeon.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.dd.morphingbutton.MorphingButton;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class SignupActivity extends BaseActivity {
    private EditText signupId;
    private EditText signupPw;
    private EditText signupName;
    private EditText signupPhone;
    private EditText signupEmail;
    private EditText confirmPw;
    private ImageView pwImage;
    int id=0;
    int pw=0;
    private int morphCounter1=1;
    private int morphCounter2=1;
    private int morphCounter3=1;
    private int morphCounter4=1;


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        signupId = (EditText) findViewById(R.id.signupEditId);
        signupPw = (EditText) findViewById(R.id.signupEditPw);
        signupName = (EditText) findViewById(R.id.signupEditName);
        signupPhone = (EditText) findViewById(R.id.signupEditPhone);
        signupEmail = (EditText) findViewById(R.id.signupEditEmail);
        final MorphingButton cancel = (MorphingButton)findViewById(R.id.cancelBtn);
        final MorphingButton overLap = (MorphingButton)findViewById(R.id.overlapBtn);
        final MorphingButton submit = (MorphingButton)findViewById(R.id.signupBtn1);

        confirmPw = (EditText) findViewById(R.id.pwConfirm);
        pwImage = (ImageView)findViewById(R.id.pwImage);




        confirmPw.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(signupPw.getText().toString().equals(confirmPw.getText().toString())) {
                    pwImage.setImageResource(R.drawable.success);
                    pw=1;
                }
                else {
                    pwImage.setImageResource(R.drawable.ban);
                    pw=2;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(id==1 && pw==1) {
                    String id = signupId.getText().toString();
                    String pw = signupPw.getText().toString();
                    String name = signupName.getText().toString();
                    String phone = signupPhone.getText().toString();
                    String email = signupEmail.getText().toString();
                    insertDB(id, pw, name, phone, email);
                    onMorphClicked3(submit);
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startActivity(new Intent(SignupActivity.this, MainActivity.class));
                        }},2000);
                }
                else {
                    Toast.makeText(getApplicationContext(),"ID 또는 PW를 확인 해주세요",Toast.LENGTH_SHORT).show();
                }

            }
        });

        overLap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String confirmId = signupId.getText().toString();
                    String tempRes = new overLapCheck().execute(confirmId).get();
                    if(tempRes.contains("0")) {
                        onMorphClicked1(overLap);
                        Toast.makeText(getApplicationContext(),"사용하실수 있으신 ID입니다",Toast.LENGTH_SHORT).show();
                        id=1;
                    }
                    else {
                        onMorphClicked2(overLap);
                        Toast.makeText(getApplicationContext(),"ID가 중복됩니다\n다른아이디로 바꿔주세요",Toast.LENGTH_SHORT).show();
                        id=2;
                    }

                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onMorphClicked4(cancel);


                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }},2000);
            }
        });

        morphToSquare1(overLap, 0);
        morphToSquare3(submit, 0);
        morphToSquare4(cancel, 0);
    }

    private void onMorphClicked1(final MorphingButton m) {
        if(morphCounter1==1){

            morphCounter1=0;
            morphToSuccess(m);

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter1++;
                    morphToSquare1(m,integer(R.integer.mb_animation));
                }},1500);
        }
    }


    private void onMorphClicked2(final MorphingButton m) {
        if(morphCounter2==1){

            morphCounter2=0;
            morphToFailure(m,integer(R.integer.mb_animation));

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    morphCounter2++;
                    morphToSquare1(m,integer(R.integer.mb_animation));
                }},1500);
        }
    }

    private void onMorphClicked3(final MorphingButton m) {
        if(morphCounter3 ==0) {
            morphCounter3++;
            morphToSquare3(m,integer(R.integer.mb_animation));
        }
        else if(morphCounter3==1){
            morphCounter3=0;
            morphToSuccess(m);
        }
    }

    private void onMorphClicked4(final MorphingButton m) {
        if(morphCounter4 ==0) {
            morphCounter4++;
            morphToSquare4(m,integer(R.integer.mb_animation));
        }
        else if(morphCounter4==1){
            morphCounter4=0;
            morphToFailure(m,integer(R.integer.mb_animation));
        }
    }

    private void morphToSquare1(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_80))
                .height(dimen(R.dimen.mb_height_30))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_overlap));
        btnMorph.morph(square);
    }

    private void morphToSquare3(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_80))
                .height(dimen(R.dimen.mb_height_30))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_submit));
        btnMorph.morph(square);
    }

    private void morphToSquare4(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params square = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_corner_radius_2))
                .width(dimen(R.dimen.mb_width_80))
                .height(dimen(R.dimen.mb_height_30))
                .color(color(R.color.econg_loginDefault))
                .colorPressed(color(R.color.econg_loginClicked))
                .text(getString(R.string.econg_cancel));
        btnMorph.morph(square);
    }


    private void morphToSuccess(final MorphingButton btnMorph) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(integer(R.integer.mb_animation))
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_green))
                .colorPressed(color(R.color.mb_green_dark))
                .icon(R.drawable.checker2);
        btnMorph.morph(circle);
    }

    private void morphToFailure(final MorphingButton btnMorph, int duration) {
        MorphingButton.Params circle = MorphingButton.Params.create()
                .duration(duration)
                .cornerRadius(dimen(R.dimen.mb_height_56))
                .width(dimen(R.dimen.mb_height_56))
                .height(dimen(R.dimen.mb_height_56))
                .color(color(R.color.mb_red))
                .colorPressed(color(R.color.mb_red_dark))
                .icon(R.drawable.canceler2);
        btnMorph.morph(circle);
    }

    /*
    public void insert(View view) {
        if(id==1 && pw==1) {
            String id = signupId.getText().toString();
            String pw = signupPw.getText().toString();
            String name = signupName.getText().toString();
            String phone = signupPhone.getText().toString();
            String email = signupEmail.getText().toString();
            insertDB(id, pw, name, phone, email);
            startActivity(new Intent(SignupActivity.this, MainActivity.class));
        }
        else {
            Toast.makeText(getApplicationContext(),"ID 또는 PW를 확인 해주세요",Toast.LENGTH_SHORT).show();
        }
    }
    */

    private void insertDB(String id, String pw, String name, String phone, String email) {
        class insertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(SignupActivity.this, "Please Wait", null, true, true);
            }

            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),"저장되었습니다! 감사합니다", Toast.LENGTH_SHORT).show();
            }

            protected String doInBackground(String... params) {
                try {
                    String iid = (String) params[0];
                    String ppw = (String) params[1];
                    String nname = (String) params[2];
                    String pphone = (String) params[3];
                    String eemail = (String) params[4];


                    //String taeLink="http://52.78.186.198/Signup_controller.php";
                    String eikLink = "http://smij.dothome.co.kr/Signup_controller.php";
                    //String link = "http://192.168.60.38/ci/index.php/Signup_controller";


                    String data = URLEncoder.encode("iid", "UTF-8") + "=" + URLEncoder.encode(iid, "UTF-8");
                    data += "&" + URLEncoder.encode("ppw", "UTF-8") + "=" + URLEncoder.encode(ppw, "UTF-8");
                    data += "&" + URLEncoder.encode("nname", "UTF-8") + "=" + URLEncoder.encode(nname, "UTF-8");
                    data += "&" + URLEncoder.encode("pphone", "UTF-8") + "=" + URLEncoder.encode(pphone, "UTF-8");
                    data += "&" + URLEncoder.encode("eemail", "UTF-8") + "=" + URLEncoder.encode(eemail, "UTF-8");

                    URL url = new URL(eikLink);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());


                    writer.write(data);
                    writer.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String(e.getMessage());
                }
            }
        }
        insertData task=new insertData();
        task.execute(id,pw,name,phone,email);
    }


    class overLapCheck extends AsyncTask<String, Void, String> {
        protected void onPreExecute() { }
        @Override
        protected String doInBackground(String... params) {
            try {
                String userId = params[0];


                //String taeLink = "http://52.78.186.198/OverlapCheck.php?userId="+userId;
                String eikLink = "http://smij.dothome.co.kr/OverlapCheck.php?userId="+userId;
                //String link = "http://192.168.60.38/ci/index.php/OverlapCheck?userId="+userId;


                URL url = new URL(eikLink);
                HttpClient client = getThreadSafeClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(eikLink));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                Log.w("Exception = ", e.getMessage());
            }
            return null;
        }
        protected void onPostExecute(String result) {}
    }


    public static DefaultHttpClient getThreadSafeClient()  {

        DefaultHttpClient client = new DefaultHttpClient();
        ClientConnectionManager mgr = client.getConnectionManager();
        HttpParams params = client.getParams();
        client = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
                mgr.getSchemeRegistry()), params);
        return client;
    }
}
