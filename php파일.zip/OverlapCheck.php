<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    $conn = mysqli_connect("127.0.0.1","root","asdf1234","smij");
    //$conn = mysqli_connect("smij.dothome.co.kr","smij","asdf1234","smij");

    if(!$conn) {
        die("DB connection failed".mysqli_error());
    }

    $dbname = "smij";

    $dbconn = mysqli_select_db($conn,$dbname);
    if(!$dbconn) {
        die("DB selection failed".mysqli_error());
    }

    $userId = $_GET['userId'];
    $query_search = "SELECT * FROM login WHERE id='$userId'";
    
    $result = mysqli_query($conn,$query_search);
    $row = mysqli_num_rows($result);

    
    echo $row;

    mysqli_close($conn);
?>